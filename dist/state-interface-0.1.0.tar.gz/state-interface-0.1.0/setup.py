# -*- coding: utf-8 -*-
from setuptools import setup

packages = \
['state_interface']

package_data = \
{'': ['*']}

setup_kwargs = {
    'name': 'state-interface',
    'version': '0.1.0',
    'description': 'ASE STATE interface',
    'long_description': None,
    'author': 'ueda',
    'author_email': 'ueda@cp.prec.eng.osaka-u.ac.jp',
    'maintainer': None,
    'maintainer_email': None,
    'url': None,
    'packages': packages,
    'package_data': package_data,
    'python_requires': '>=3.7,<4.0',
}


setup(**setup_kwargs)
